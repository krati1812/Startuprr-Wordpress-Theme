<div class="wrap" style="background-color:#fff; padding:40px 30px;">
<p>
  <h1> <strong>TC Team Members by themescode.com</strong></h1>
  <br>
<a class="tc-button tc-btn-green" href="https://www.themescode.com/items/tc-team-members" target="_blank">Plugin Home</a>
<a class="tc-button tc-btn-blue" href="http://teammembers.themescode.com" target="_blank">Live Demo</a>
 <a class="tc-button tc-btn-lime" href="http://docs.themescode.com/tc-team-members-pro" target="_blank">Documentation</a>
  <a class="tc-button tc-btn-blue" href="https://www.themescode.com/support/" target="_blank">Support</a>
 <a class="tc-button tc-btn-orange" href="https://profiles.wordpress.org/themescode/#content-plugins" target="_blank">More Free Plugins</a>
</p>
<h3>Follow This Video Tutorial to work with this plugin.</h3>
<iframe width="560" height="315" src="https://www.youtube.com/embed/G0A2aqhzxAw" frameborder="0" allowfullscreen></iframe>

<h3 style="padding-left:0">Available features at TC Team Members - PRO</h3>
  <ol class="pro-features">
 <li> Member’s more details are shown in a Pop-up window</li>
 <li> 8 Different Layout Style</li>
 <li>5 Nice Image Hover Effects</li>
 <li>Overlay effects for Layout Style 5 & 6</li>
 <li>Background & Titles Color Hover Effects</li>
 <li>6 Different Social Icon Style.</li>
 <li>Show 4 Social Icons from 10 available Icons.</li>
 <li>Support within 6 hours.</li>
 <li>Price is very Reasonable.</li>
 <li>Amazing setting panel..</li>
 <li>Unlimited Member Image Transparent Color Overlay on Hover.</li>
 <li>Text Color Changeable.</li>
 <li>Text Alignment changeable.</li>
 <li>Social Icon Alignment changeable.</li>
 <li>And many more…</li>
  </ol>
  <a class="tc-button tc-btn-red"
    target="_blank" href="https://www.themescode.com/items/tc-team-members/">Upgrade To PRO!
  </a>

</div> <!-- wrap end  -->
