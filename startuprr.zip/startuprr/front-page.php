<!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="<?php bloginfo('description'); ?>">
    <title>
      <?php bloginfo('name'); ?> |
      <?php is_front_page() ? bloginfo('description') : wp_title(); ?>
    </title>
    <!-- Bootstrap core CSS -->
    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
	  <link rel='stylesheet' id='shapely-fonts-css'  href='//fonts.googleapis.com/css?family=Raleway%3A100%2C300%2C400%2C500%2C600%2C700%7COpen+Sans%3A400%2C500%2C600&#038;ver=4.9.8' type='text/css' media='all' />
	  
	
    <?php wp_head(); ?>
    <style>
      .showcase{
        background:url(<?php echo get_theme_mod('showcase_image', get_bloginfo('template_url').'/img/showcase.jpg'); ?>) no-repeat center center;
      }
		.secbg4{background:url(<?php echo get_theme_mod('sec_four_image', get_bloginfo('template_url').'/img/sec44.png'); ?>) no-repeat center center #151515;
		background-size:cover;}
    </style>
  </head>
  <body>
	  <section class="section_head">  <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
		   <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
         
			   <div class="custom_logo">
				   <?php 
				   if ( function_exists( 'the_custom_logo' ) ) {
    the_custom_logo();
}
				   ?>
				   
			   </div>
	
        </div>
		 
       
          <?php
           wp_nav_menu( array(
               'menu'              => 'primary',
               'theme_location'    => 'primary',
               'depth'             => 2,
               'container'         => 'div',
               'container_class'   => 'navbar-collapse collapse',
       'container_id'      => 'navbar',
               'menu_class'        => 'nav navbar-nav navbar-right',
               'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
               'walker'            => new wp_bootstrap_navwalker())
           );
       ?>
          
		
      </div>
    </nav></section>
    

<section class="showcase">
  <div class="container">
	  <div class="row">
				<div class="col-md-5 col-sm-6 col-xs-12">
					<p class="smalltext">
						<?php echo get_theme_mod('showcase_small_text', 'What are you waiting for?'); ?>
					</p>
					 <h1><?php echo get_theme_mod('showcase_heading', 'Lets be Creative'); ?></h1>
    <p class="blkbg"><?php echo get_theme_mod('showcase_text', 'Startuprr, NEXT GENERATION & HIGHLY FLEXIBLE WORDPRESS THEME'); ?></p>
					<p class="design-label">
					<?php echo get_theme_mod('showcase_text_design', 'start doing that'); ?></p>
					
					<a class="scroll_btn" href="#middle"><span></span></a>
					
    
				</div>
				
			</div>
   
  </div>
</section>
	  
	<section id="middle" class="section_third">  
		<div class="Container">
			<div class="row">
				<div class="col-xs-12">
					<h3 class="design-heading"><?php echo get_theme_mod('section_third_heading', 'What We Offer'); ?></h3>
    <p class="text_middle"><?php echo get_theme_mod('section_third_text', 'We offer our customers the best services & solutions, this is our main services list'); ?></p>
					
	
				</div>
				
			</div>
			
		</div>
			</section>

<section class="boxes">
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-4 text-center mb20">
		  <span class="icon-circle"><i class="fa fa-desktop" aria-hidden="true"></i></span>
          <?php if(is_active_sidebar('box1')) : ?>
            <?php dynamic_sidebar('box1'); ?>
          <?php endif; ?>
		  <a href="<?php echo get_theme_mod('btn_url_one', 'http://test.com'); ?>" class="btn btn-primary btn-sm"><?php echo get_theme_mod('btn_text_one', 'Read More'); ?></a>
      </div>

      <div class="col-md-4 col-sm-4 text-center">
		  <span class="icon-circle icon-circlemid"><i class="fa fa-puzzle-piece" aria-hidden="true"></i></span>
          <?php if(is_active_sidebar('box2')) : ?>
            <?php dynamic_sidebar('box2'); ?>
          <?php endif; ?>
		  
		  <a href="<?php echo get_theme_mod('btn_url_two', 'http://test.com'); ?>" class="btn btn-primary btn-sm btn-fill"><?php echo get_theme_mod('btn_text_two', 'Read More'); ?></a>
      </div>

      <div class="col-md-4 col-sm-4  text-center">
		  <span class="icon-circle"><i class="fa fa-support" aria-hidden="true"></i></span>
          <?php if(is_active_sidebar('box3')) : ?>
            <?php dynamic_sidebar('box3'); ?>
          <?php endif; ?>
		  <a href="<?php echo get_theme_mod('btn_url_three', 'http://test.com'); ?>" class="btn btn-primary btn-sm"><?php echo get_theme_mod('btn_text_three', 'Read More'); ?></a>
      </div>
    </div>
  </div>
</section>

	  	<section class="section_features secbg4">  
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h3 class="design-heading clwhite"><?php echo get_theme_mod('section_features_heading', 'Amazing Features'); ?></h3>
    <p class="text_middle clwhite"><?php echo get_theme_mod('section_features_text', 'With unlimited features that we offer, we promise its possible to make everything that was impossible for you!'); ?></p>
					</div>
					
				</div>
				
				
				
				<div class="row">
					<div class="col-md-6 col-sm-6 col-xs-12 ">
							
				<div class="row mb20">
					<span class="side-icon">
						<i class="fa fa-desktop" aria-hidden="true"></i>
					</span>
					<div class="custom-div">
						<h3 class=""><?php echo get_theme_mod('features_sub_heading_one', 'Responsive & Multipurpose'); ?></h3>
						
    <p class="center"><?php echo get_theme_mod('features_Subtext_one', 'Aenean eu leo quam. Sociis natoque penatibus et magnis dis parturient montes'); ?></p>
					</div>
								</div>
								
								
								<div class="row mb20">
					<span class="side-icon">
						<i class="fa fa-puzzle-piece" aria-hidden="true"></i>
					</span>
					<div class="custom-div">
						<h3 class=""><?php echo get_theme_mod('features_sub_heading_two', 'Easy Customization'); ?></h3>
						
    <p class="center"><?php echo get_theme_mod('features_Subtext_two', 'Nascetur ridiculus mus. Aenean eu leo quam. Sociis natoque penatibus et magnis dis parturient montes'); ?></p>
					</div>
								</div>
								
								
								<div class="row mb20">
					<span class="side-icon">
						<i class="fa fa-star" aria-hidden="true"></i>
					</span>
					<div class="custom-div">
						<h3 class=""><?php echo get_theme_mod('features_sub_heading_three', 'Unlimited Features'); ?></h3>
						
    <p class="center"><?php echo get_theme_mod('features_Subtext_three', 'Nascetur ridiculus mus. Aenean eu leo quam. Sociis natoque penatibus et magnis dis parturient montes'); ?></p>
					</div>
								</div>
						</div>
					
					<div class="col-md-6 col-sm-6 col-xs-12 ">
					
					</div>
						
						
					</div>
				
				
			</div>
			
		
			
			
					
					
					
			
		</section>
	  
	  <section class="section_all_features">
       <div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-4">
		   <span class="side-icon-b">
				  <span class="sec-icon-bg">
				  <i class="fa fa-desktop" aria-hidden="true"></i>
				  </span>
					</span>
		  <div class="custom-div2">
			  <?php if(is_active_sidebar('feature1')) : ?>
            <?php dynamic_sidebar('feature1'); ?>
          <?php endif; ?>
		  </div>
		  
          
      </div>
		
		  <div class="col-md-4 col-sm-4">
			  <span class="side-icon-b">
				  <span class="sec-icon-bg">
				  <i class="fa fa-puzzle-piece" aria-hidden="true"></i>
				  </span>
					</span>
			  <div class="custom-div2">
				     <?php if(is_active_sidebar('feature2')) : ?>
            <?php dynamic_sidebar('feature2'); ?>
          <?php endif; ?>
			  </div>
       
      </div>
		
		  <div class="col-md-4 col-sm-4">
			   <span class="side-icon-b">
				  <span class="sec-icon-bg">
				  <i class="fa fa-star" aria-hidden="true"></i>
				  </span>
					</span>
			  <div class="custom-div2">
			  <?php if(is_active_sidebar('feature3')) : ?>
            <?php dynamic_sidebar('feature3'); ?>
          <?php endif; ?>
			  </div>
          
      </div>
		
		  <div class="col-md-4 col-sm-4">
			   <span class="side-icon-b">
				  <span class="sec-icon-bg">
				  <i class="fa fa-file" aria-hidden="true"></i>
				
				  </span>
					</span>
			  <div class="custom-div2">
				    <?php if(is_active_sidebar('feature4')) : ?>
            <?php dynamic_sidebar('feature4'); ?>
          <?php endif; ?>
			  </div>
        
      </div>
		
		  <div class="col-md-4 col-sm-4">
			   <span class="side-icon-b">
				  <span class="sec-icon-bg">
				  <i class="fa fa-shopping-cart" aria-hidden="true"></i>
				  </span>
					</span>
			  <div class="custom-div2">
			      <?php if(is_active_sidebar('feature5')) : ?>
            <?php dynamic_sidebar('feature5'); ?>
          <?php endif; ?>
			  </div>
      
      </div>
		
		  <div class="col-md-4 col-sm-4">
			   <span class="side-icon-b">
				  <span class="sec-icon-bg">
				  <i class="fa fa-support" aria-hidden="true"></i>
				  </span>
					</span>
			  <div class="custom-div2">
				   <?php if(is_active_sidebar('feature6')) : ?>
            <?php dynamic_sidebar('feature6'); ?>
          <?php endif; ?>
			  </div>
         
      </div>
		
		   </div>
		  </div>
        </section>
	
	  
	  	 <section class="section_sw_head">
		 <div class="container">
			   <div class="row">
				   <div class="col-md-12">
					     <h3 class="design-heading"><?php echo get_theme_mod('section_sw_heading', 'Sample Work'); ?></h3>
    <p class="text_middle"><?php echo get_theme_mod('section_sw_text', 'lets take a look at some of the best of our works here, we love them and hope you too'); ?></p>
		
				   </div></div>
			 <div class="row">
				 <?php if(is_active_sidebar('workportfolio')) : ?>
            <?php dynamic_sidebar('workportfolio'); ?>
          <?php endif; ?>
			 </div>
			 
			 </div>
                    </section>
                    
                      <section class="section_btn_view_work">
		  <div class="container">
			   <div class="row">
				   <div class="col-md-12">
					    <a href="<?php echo get_theme_mod('section_btn_view_work_url', 'http://test.com'); ?>" class="btn btn-primary btn-fill btn-full"><?php echo get_theme_mod('section_btn_view_work_text', 'view all work'); ?></a>
				   </div>
			  </div>
		  </div>
	  </section>
	  
	  <section class="section_company_facts">
		  <span class="divider" style="top: -30px;"><i class="fa fa-caret-up"></i></span>
		   <div class="container">
			   <div class="row">
				   <div class="col-md-12">
					     <h3 class="design-heading clwhite"><?php echo get_theme_mod('section_c_facts_heading', 'Company Facts'); ?></h3>
    <p class="cf"><?php echo get_theme_mod('section_c_facts_text', 'lets take a look at some of the best of our works here, we love them and hope you too'); ?></p>
				   </div>
			 
			   </div>
			   
			   <div class="row">
				   <div class="col-md-3 col-sm-3">
					   <p class="number"><?php echo get_theme_mod('section_c_num_one', '218'); ?></p>
					   <span class="divider_number"><i class="fa fa-check-square"></i></span>
					   <p class="title-for-number">
						   Completed Projects
					   </p>
				   </div>
				     
				     <div class="col-md-3 col-sm-3">
					   <p class="number fill"><?php echo get_theme_mod('section_c_num_two', '360'); ?></p>
					   <span class="divider_number"><i class="fa fa-hourglass-half"></i></span>
					   <p class="title-for-number">
						    Hours of work<span style="font-size: 6px;">/Month</span>
					   </p>
				   </div>
				   
				     <div class="col-md-3 col-sm-3">
					   <p class="number"><?php echo get_theme_mod('section_c_num_three', '135'); ?></p>
					   <span class="divider_number"><i class="fa fa-tags"></i></span>
					   <p class="title-for-number">
						   Solved Tickets
					   </p>
				   </div>
				   
				     <div class="col-md-3 col-sm-3">
					    <p class="number"><?php echo get_theme_mod('section_c_num_four', '174'); ?></p>
					   <span class="divider_number"><i class="fa fa-thumbs-up"></i></span>
					   <p class="title-for-number">
						   Satisfied Client
					   </p>
				   </div>
				   
				   
			   </div>
			   
		  
		  </div>
	  </section>
	  
	  <section class="section_ask">
	  <div class="container">
		  <div class="row">
		  <div class="col-md-8 col-sm-6">
			     <p class="text_middle"><?php echo get_theme_mod('section_ask_text', 'Are you satisfied with the unlimited features that we offer'); ?></p>
			  </div>
			  <div class="col-md-4 col-sm-6">
			    <a href="<?php echo get_theme_mod('section_ask_btn_url_one', 'http://test.com'); ?>" class="btn btn-primary btn-sm btn-fill-grey"><?php echo get_theme_mod('section_ask_btn_text_one', 'Purchase it Now'); ?></a>
				    <a href="<?php echo get_theme_mod('section_ask_one_btn_url_two', 'http://test.com'); ?>" class="btn btn-primary btn-sm btn-fill-grey"><?php echo get_theme_mod('section_ask_btn_text_two', 'Contact Us Now'); ?></a>
				  
			  </div>
		  </div></div>
	  </section>
	  

	  
	  <section class="section_team">
		  <div class="container">
			   <div class="row">
				   <div class="col-md-12">
					     <h3 class="design-heading"><?php echo get_theme_mod('section_team_heading', 'Company Facts'); ?></h3>
    <p class="text_middle"><?php echo get_theme_mod('section_team_text', 'lets take a look at some of the best of our works here, we love them and hope you too'); ?></p>
				   </div>
			 
				   <div class="row">
					   <?php if(is_active_sidebar('team')) : ?>
            <?php dynamic_sidebar('team'); ?>
          <?php endif; ?>
				   </div>
			   </div>
		  </div>
		  
		  
	  </section>
	  
	  <section class="section_testimonial">
		  <span class="divider blk-divi" style="top: -30px;"><i class="fa fa-quote-left"></i></span>
	   <div class="container">
		  <div class="row">
			  <div class="testimonial-div">
				  <?php if(is_active_sidebar('testimonial')) : ?>
            <?php dynamic_sidebar('testimonial'); ?>
          <?php endif; ?>
			  </div>
			  
		  </div>
		  </div>
	  </section>
	  
	  
	  
	  <section class="section_client_slider">
	  <div class="container">
		  <div class="row">
			  <div class="client-div">
				  <?php if(is_active_sidebar('client')) : ?>
            <?php dynamic_sidebar('client'); ?>
          <?php endif; ?>
			  </div>
			  
		  </div>
		  </div>
	  </section>
	  
	  <section class="section_price">
		  <div class="container">
			  <div class="row">
				  <div class="col-md-12">
					     <h3 class="design-heading"><?php echo get_theme_mod('section_price_heading', 'Real Cheap Prices'); ?></h3>
    <p class="text_middle"><?php echo get_theme_mod('section_price_text', 'lets take a look at some of the best of our works here, we love them and hope you too'); ?></p>
					  
				  </div>
				  
			  </div>
			  <div class="row">
				  <div class="col-md-12">
					   <?php if(is_active_sidebar('pricetable')) : ?>
            <?php dynamic_sidebar('pricetable'); ?>
          <?php endif; ?>
					  
				  </div>
			  </div>
			  
		  </div>
	  </section>
	  
	  <section class="section_purchase">
		  <div class="container">
			  <div class="row">
				  <div class="col-md-8">
					<p><?php echo get_theme_mod('section_purchase_text', 'Unique! We do love it, and hope you too'); ?></p>
					 
				  </div>
				  
				    <div class="col-md-4 text-center">
					  <a href="<?php echo get_theme_mod('section_purchase_btn_url', 'http://test.com'); ?>" class="btn btn-primary btn-md btn-fill"><i class="fa fa-shopping-cart"></i> <?php echo get_theme_mod('section_purchase_btn_text', 'Purchase it Now'); ?></a>
						
				  </div>
			  </div>
			  
		  </div>
	  
	  </section>
	  
	  <section class="section_social">
		  <span class="divider" style="top: -30px;"><i class="fa fa-caret-up"></i></span>
		  <div class="container">
			  <div class="row">
				  <div class="col-md-12">
					  <div class="custom_logo logocust">
				   <?php 
				   if ( function_exists( 'the_custom_logo' ) ) {
    the_custom_logo();
}
				   ?>
				   
			   </div>
	
						  	 <?php if(is_active_sidebar('social')) : ?>
            <?php dynamic_sidebar('social'); ?>
          <?php endif; ?>
					 
					  
				  </div>
				  
			  </div>
			  
		  </div>
	  </section>
	  
<section class="section_contact">
	<div class="map-big-container">
		<div class="map-container">
	<div id="map">
		
			</div>
	</div>
	</div>
	
	
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-sm-4 col-xs-6">
				   <?php if(is_active_sidebar('contact')) : ?>
            <?php dynamic_sidebar('contact'); ?>
          <?php endif; ?>
			</div>
		</div>
		
	</div>
	  
	  </section>
	  
<footer class="blog-footer">
	<span class="divider" style="top: -30px;"><i class="fa fa-caret-up"></i></span>
  <p class="copy-right">Copyright &copy; <?php echo Date('Y'); ?> - <?php bloginfo('name'); ?>. All Rights Reserved</p>
  <p>
    <a href="#">Back to top</a>
  </p>
</footer>
<?php wp_footer(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
	<script src="<?php bloginfo('template_url'); ?>/js/map.js"></script>  
	    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCk-MKtcB05Tm4i-yZlEUAFJbFAcah22IE&callback=initMap"
    async defer></script>
	  

</body>
</html>
