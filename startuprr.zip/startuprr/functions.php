<?php
  // Register Nav Walker class_alias
  require_once('wp_bootstrap_navwalker.php');

  // Theme Support
  function wpb_theme_setup(){
    add_theme_support('post-thumbnails');
	

    // Nav Menus
    register_nav_menus(array(
      'primary' => __('Primary Menu')
    ));

    // Post Formats
    add_theme_support('post-formats', array('aside', 'gallery'));
  }

  add_action('after_setup_theme','wpb_theme_setup');

// custom logo
function wpb_custom_logo_setup() {
    $defaults = array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
        'header-text' => array( 'site-title', 'site-description' ),
    );
    add_theme_support( 'custom-logo', $defaults );
}
add_action( 'after_setup_theme', 'wpb_custom_logo_setup' );

// Excerpt Length Control
function set_excerpt_length(){
  return 45;
}

add_filter('excerpt_length', 'set_excerpt_length');

// Widget Locations
function wpb_init_widgets($id){
  register_sidebar(array(
    'name'  => 'Sidebar',
    'id'    => 'sidebar',
    'before_widget' => '<div class="sidebar-module">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));

  register_sidebar(array(
    'name'  => 'Box1',
    'id'    => 'box1',
    'before_widget' => '<div class="box">',
    'after_widget'  => '</div>',
    'before_title'  => '<h3>',
    'after_title'   => '</h3>'
  ));

  register_sidebar(array(
    'name'  => 'Box2',
    'id'    => 'box2',
    'before_widget' => '<div class="box">',
    'after_widget'  => '</div>',
    'before_title'  => '<h3>',
    'after_title'   => '</h3>'
  ));

  register_sidebar(array(
    'name'  => 'Box3',
    'id'    => 'box3',
    'before_widget' => '<div class="box">',
    'after_widget'  => '</div>',
    'before_title'  => '<h3>',
    'after_title'   => '</h3>'
  ));
	
	 register_sidebar(array(
    'name'  => 'Feature1',
    'id'    => 'feature1',
    'before_widget' => '<div class="box-feature">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	 register_sidebar(array(
    'name'  => 'Feature2',
    'id'    => 'feature2',
    'before_widget' => '<div class="box-feature">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	 register_sidebar(array(
    'name'  => 'Feature3',
    'id'    => 'feature3',
    'before_widget' => '<div class="box-feature">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	 register_sidebar(array(
    'name'  => 'Feature4',
    'id'    => 'feature4',
    'before_widget' => '<div class="box-feature">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	 register_sidebar(array(
    'name'  => 'Feature5',
    'id'    => 'feature5',
    'before_widget' => '<div class="box-feature">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	 register_sidebar(array(
    'name'  => 'Feature6',
    'id'    => 'feature6',
    'before_widget' => '<div class="box-feature">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	 register_sidebar(array(
    'name'  => 'Contact',
    'id'    => 'contact',
    'before_widget' => '<div class="contact-div">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	register_sidebar(array(
    'name'  => 'map',
    'id'    => 'map',
    'before_widget' => '<div class="map-div">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	register_sidebar(array(
    'name'  => 'social',
    'id'    => 'social',
    'before_widget' => '<div class="social-links">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	register_sidebar(array(
    'name'  => 'pricetable',
    'id'    => 'pricetable',
    'before_widget' => '<div class="pricetable-div">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	register_sidebar(array(
    'name'  => 'client',
    'id'    => 'client',
    'before_widget' => '<div class="client-div">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	register_sidebar(array(
    'name'  => 'testimonial',
    'id'    => 'testimonial',
    'before_widget' => '<div class="testimonial-div">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	register_sidebar(array(
    'name'  => 'team',
    'id'    => 'team',
    'before_widget' => '<div class="team-div">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	register_sidebar(array(
    'name'  => 'workportfolio',
    'id'    => 'workportfolio',
    'before_widget' => '<div class="team-div">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
  ));
	
	
}

add_action('widgets_init', 'wpb_init_widgets');

// Customizer File
require get_template_directory(). '/inc/customizer.php';
