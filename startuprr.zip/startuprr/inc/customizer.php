<?php
  function wpb_customize_register($wp_customize){
    // Showcase Section
    $wp_customize->add_section('showcase', array(
      'title'   => __('Showcase', 'startuprr'),
      'description' => sprintf(__('Options for showcase','startuprr')),
      'priority'    => 130
    ));

    $wp_customize->add_setting('showcase_image', array(
      'default'   => get_bloginfo('template_directory').'/img/showcase.jpg',
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'showcase_image', array(
      'label'   => __('Showcase Image', 'startuprr'),
      'section' => 'showcase',
      'settings' => 'showcase_image',
      'priority'  => 1
    )));

	   $wp_customize->add_setting('showcase_small_text', array(
      'default'   => _x('What are you waiting for?', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('showcase_small_text', array(
      'label'   => __('Upper Small Line', 'startuprr'),
      'section' => 'showcase',
      'priority'  => 2
    ));


    $wp_customize->add_setting('showcase_heading', array(
      'default'   => _x('Lets be Creative', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('showcase_heading', array(
      'label'   => __('Heading', 'startuprr'),
      'section' => 'showcase',
      'priority'  => 3
    ));

    $wp_customize->add_setting('showcase_text', array(
      'default'   => _x('Startuprr, NEXT GENERATION & HIGHLY FLEXIBLE WORDPRESS THEME', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('showcase_text', array(
      'label'   => __('Black Text', 'startuprr'),
      'section' => 'showcase',
      'priority'  => 4
    ));
	  
	     $wp_customize->add_setting('showcase_text_design', array(
      'default'   => _x('start doing that', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('showcase_text_design', array(
      'label'   => __('Design Heading', 'startuprr'),
      'section' => 'showcase',
      'priority'  => 5
    ));

  
	  
	  // Section Boxes Btn
	  
	  $wp_customize->add_section('boxes', array(
      'title'   => __('Boxes', 'startuprr'),
      'description' => sprintf(__('Options for showcase','startuprr')),
      'priority'    => 140
    ));

	  
	    $wp_customize->add_setting('btn_url_one', array(
      'default'   => _x('http://test.com', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('btn_url_one', array(
      'label'   => __('Button URL One', 'startuprr'),
      'section' => 'boxes',
      'priority'  => 1
    ));

    $wp_customize->add_setting('btn_text_one', array(
      'default'   => _x('Read More', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('btn_text_one', array(
      'label'   => __('Button Text', 'startuprr'),
      'section' => 'boxes',
      'priority'  => 2
    ));
	  
	  
	   $wp_customize->add_setting('btn_url_two', array(
      'default'   => _x('http://test.com', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('btn_url_two', array(
      'label'   => __('Button URL', 'startuprr'),
      'section' => 'boxes',
      'priority'  => 3
    ));

    $wp_customize->add_setting('btn_text_two', array(
      'default'   => _x('Read More', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('btn_text_two', array(
      'label'   => __('Button Text', 'startuprr'),
      'section' => 'boxes',
      'priority'  => 4
    ));
	  
	   $wp_customize->add_setting('btn_url_three', array(
      'default'   => _x('http://test.com', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('btn_url_three', array(
      'label'   => __('Button URL', 'startuprr'),
      'section' => 'boxes',
      'priority'  => 5
    ));

    $wp_customize->add_setting('btn_text_three', array(
      'default'   => _x('Read More', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('btn_text_three', array(
      'label'   => __('Button Text', 'startuprr'),
      'section' => 'boxes',
      'priority'  => 6
    ));
	  
	  
	  
	   // Section Third
    $wp_customize->add_section('section_third', array(
      'title'   => __('What We Offer Services', 'startuprr'),
      'description' => sprintf(__('Options for showcase','startuprr')),
      'priority'    => 150
    ));
	  
	   $wp_customize->add_setting('section_third_heading', array(
      'default'   => _x('What We Offer', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_third_heading', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_third',
      'priority'  => 1
    ));
	  
	    $wp_customize->add_setting('section_third_text', array(
      'default'   => _x('We offer our customers the best services & solutions, this is our main services list', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_third_text', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_third',
      'priority'  => 2
    ));
	  
	  
	  // Section Features
    $wp_customize->add_section('section_features', array(
      'title'   => __('Amazing Features', 'startuprr'),
      'description' => sprintf(__('Options for showcase','startuprr')),
      'priority'    => 160
    ));
	  
	   $wp_customize->add_setting('section_features_heading', array(
      'default'   => _x('Amazing Features', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_features_heading', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_features',
      'priority'  => 1
    ));
	  
	    $wp_customize->add_setting('section_features_text', array(
      'default'   => _x('With unlimited features that we offer, we promise its possible to make everything that was impossible for you!', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_features_text', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_features',
      'priority'  => 2
    ));
	  
	   $wp_customize->add_setting('features_sub_heading_one', array(
      'default'   => _x('Responsive & Multipurpose', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('features_sub_heading_one', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_features',
      'priority'  => 3
    ));
	  
	    $wp_customize->add_setting('features_Subtext_one', array(
      'default'   => _x('Aenean eu leo quam. Sociis natoque penatibus et magnis dis parturient montes', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('features_Subtext_one', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_features',
      'priority'  => 4
    ));
	  
	     $wp_customize->add_setting('features_sub_heading_two', array(
      'default'   => _x('Easy Customization', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('features_sub_heading_two', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_features',
      'priority'  => 5
    ));
	  
	    $wp_customize->add_setting('features_Subtext_two', array(
      'default'   => _x('Aenean eu leo quam. Sociis natoque penatibus et magnis dis parturient montes', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('features_Subtext_two', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_features',
      'priority'  => 6
    ));
	  
	  
	  $wp_customize->add_setting('features_sub_heading_three', array(
      'default'   => _x('Unlimited Features', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('features_sub_heading_three', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_features',
      'priority'  => 7
    ));
	  
	    $wp_customize->add_setting('features_Subtext_three', array(
      'default'   => _x('Aenean eu leo quam. Sociis natoque penatibus et magnis dis parturient montes', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('features_Subtext_three', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_features',
      'priority'  => 8
    ));
	    
	   $wp_customize->add_setting('sec_four_image', array(
      'default'   => get_bloginfo('template_directory').'/img/sec44.png',
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'sec_four_image', array(
      'label'   => __('Right Hand Side Image', 'startuprr'),
      'section' => 'section_features',
      'settings' => 'sec_four_image',
      'priority'  => 9
    )));
	  
	
	    // Section Simple Work Heading
    $wp_customize->add_section('section_sw_head', array(
      'title'   => __('Simple Work', 'startuprr'),
      'description' => sprintf(__('Options for showcase','startuprr')),
      'priority'    => 170
    ));
	  
	   $wp_customize->add_setting('section_sw_heading', array(
      'default'   => _x('Sample Work', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_sw_heading', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_sw_head',
      'priority'  => 1
    ));
	  
	    $wp_customize->add_setting('section_sw_text', array(
      'default'   => _x('Lets take a look at some of the best of our works here, we love them and hope you too!', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_sw_text', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_sw_head',
      'priority'  => 2
    ));
	  
	   // Purchase Button and Text Section
    $wp_customize->add_section('section_purchase', array(
      'title'   => __('Purchase Text', 'startuprr'),
      'description' => sprintf(__('Options for section_purchase','startuprr')),
      'priority'    => 180
    ));
	  
	    $wp_customize->add_setting('section_purchase_text', array(
      'default'   => _x('Unique! We do love it, and hope you too', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_purchase_text', array(
      'label'   => __('Side Text', 'startuprr'),
      'section' => 'section_purchase',
      'priority'  => 1
    ));
	  
	  $wp_customize->add_setting('section_purchase_btn_url', array(
      'default'   => _x('http://test.com', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_purchase_btn_url', array(
      'label'   => __('Button URL', 'startuprr'),
      'section' => 'section_purchase',
      'priority'  => 2
    ));

    $wp_customize->add_setting('section_purchase_btn_text', array(
      'default'   => _x('Purchase it now', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_purchase_btn_text', array(
      'label'   => __('Button Text', 'startuprr'),
      'section' => 'section_purchase',
      'priority'  => 3
    ));
	  
	   // Price Heading And Text Section
    $wp_customize->add_section('section_price', array(
      'title'   => __('Price Heading', 'startuprr'),
      'description' => sprintf(__('Options for section_price','startuprr')),
      'priority'    => 190
    ));
	  
	    $wp_customize->add_setting('section_price_heading', array(
      'default'   => _x('Real Cheap Prices', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_price_heading', array(
      'label'   => __('Heading', 'startuprr'),
      'section' => 'section_price',
      'priority'  => 1
    ));
	  
	    $wp_customize->add_setting('section_price_text', array(
      'default'   => _x('lets take a look at some of the best of our works here, we love them and hope you too', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_price_text', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_price',
      'priority'  => 2
    ));
	  
	   // Ask Section
    $wp_customize->add_section('section_ask', array(
      'title'   => __('Ask Purchase or Contact', 'startuprr'),
      'description' => sprintf(__('Options for section_ask','startuprr')),
      'priority'    => 200
    ));
	  
	    $wp_customize->add_setting('section_ask_text', array(
      'default'   => _x('Are you satisfied with the unlimited features that we offer', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_ask_text', array(
      'label'   => __('Side Text', 'startuprr'),
      'section' => 'section_ask',
      'priority'  => 1
    ));
	  
	  $wp_customize->add_setting('section_ask_btn_url_one', array(
      'default'   => _x('http://test.com', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_ask_btn_url_one', array(
      'label'   => __('Button One URL', 'startuprr'),
      'section' => 'section_ask',
      'priority'  => 2
    ));

    $wp_customize->add_setting('section_ask_btn_text_one', array(
      'default'   => _x('Purchase it now', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_ask_btn_text_one', array(
      'label'   => __('Button One Text', 'startuprr'),
      'section' => 'section_ask',
      'priority'  => 3
    ));
	  
	    $wp_customize->add_control('section_ask_btn_url_two', array(
      'label'   => __('Button Second URL', 'startuprr'),
      'section' => 'section_ask',
      'priority'  => 4
    ));

    $wp_customize->add_setting('section_ask_btn_text_two', array(
      'default'   => _x('Contact Us Now', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_ask_btn_text_two', array(
      'label'   => __('Button Second Text', 'startuprr'),
      'section' => 'section_ask',
      'priority'  => 5
    ));
	  
	    // Section Company Facts
    $wp_customize->add_section('section_company_facts', array(
      'title'   => __('Company Facts', 'startuprr'),
      'description' => sprintf(__('Options for section_company_facts','startuprr')),
      'priority'    => 210
    ));
	  
	    $wp_customize->add_setting('section_c_facts_heading', array(
      'default'   => _x('Company Facts', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_c_facts_heading', array(
      'label'   => __('Heading', 'startuprr'),
      'section' => 'section_company_facts',
      'priority'  => 1
    ));
	  
	    $wp_customize->add_setting('section_c_facts_text', array(
      'default'   => _x('Lets take a look at some of the best of our works here, we love them and hope you too', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_c_facts_text', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_company_facts',
      'priority'  => 2
    ));
	  
	   $wp_customize->add_setting('section_c_num_one', array(
      'default'   => _x('218', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_c_num_one', array(
      'label'   => __('Completed Projects', 'startuprr'),
      'section' => 'section_company_facts',
      'priority'  => 3
    ));
	  
	  
	   $wp_customize->add_setting('section_c_num_two', array(
      'default'   => _x('360', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_c_num_two', array(
      'label'   => __('Hours of work', 'startuprr'),
      'section' => 'section_company_facts',
      'priority'  => 4
    ));
	  
	   $wp_customize->add_setting('section_c_num_three', array(
      'default'   => _x('135', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_c_num_three', array(
      'label'   => __('Solved Tickets', 'startuprr'),
      'section' => 'section_company_facts',
      'priority'  => 5
    ));
	  
	    $wp_customize->add_setting('section_c_num_four', array(
      'default'   => _x('174', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_c_num_four', array(
      'label'   => __('Satisfied Clients', 'startuprr'),
      'section' => 'section_company_facts',
      'priority'  => 6
    ));
	  
	  /*View All Work Btn*/
	    $wp_customize->add_section('section_btn_view_work', array(
      'title'   => __('View All Work Button', 'startuprr'),
      'description' => sprintf(__('Options for section_btn_view_work','startuprr')),
      'priority'    => 220
    ));
	  
	   $wp_customize->add_setting('section_btn_view_work_url', array(
      'default'   => _x('http://test.com', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_btn_view_work_url', array(
      'label'   => __('Button One URL', 'startuprr'),
      'section' => 'section_btn_view_work',
      'priority'  => 1
    ));

    $wp_customize->add_setting('section_btn_view_work_text', array(
      'default'   => _x('View All Work', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_btn_view_work_text', array(
      'label'   => __('Button Text', 'startuprr'),
      'section' => 'section_btn_view_work',
      'priority'  => 2
    ));
	    // Team Headings
    $wp_customize->add_section('section_team', array(
      'title'   => __('Team Heading', 'startuprr'),
      'description' => sprintf(__('Options for section_team','startuprr')),
      'priority'    => 230
    ));
	  
	    $wp_customize->add_setting('section_team_heading', array(
      'default'   => _x('Team Members', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_team_heading', array(
      'label'   => __('Heading', 'startuprr'),
      'section' => 'section_team',
      'priority'  => 1
    ));
	  
	    $wp_customize->add_setting('section_team_text', array(
      'default'   => _x('Lets take a look at some of the best of our works here, we love them and hope you too', 'startuprr'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('section_team_text', array(
      'label'   => __('Text', 'startuprr'),
      'section' => 'section_team',
      'priority'  => 2
    ));
	  
  }

  add_action('customize_register', 'wpb_customize_register');
